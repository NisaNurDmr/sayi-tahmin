from flask import Flask, render_template, request, session
import random

app = Flask(__name__)
app.secret_key='your_secret_key'


@app.route('/')
def hello_world():
    return 'Hello, World!'

@app.route('/user/<username>')
def show_user_profile(username):
    return f'User {username}'

@app.route('/login')
def home():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username=request.form['username']
    password=request.form['password']

    if username == 'admin' and password == 'secret':
        return f'Welcome, {username}!'
    else:
        return 'Invalid credantials, please try again.'


@app.route('/sayi')
def sayi():
    return render_template('index.html')

@app.route('/sayi', methods=['GET','POST'])
def index():
    if 'number' not in session:
        session['number']=random.randint(0, 100)
        session['attempts']=0

    if request.method == 'POST':
        guess = int(request.form['guess'])
        session['attempts'] += 1

        if guess < session['number']:
            message = 'Daha büyük bir sayı tahmin edin!'
        elif guess > session['number']:
            message = 'Daha küçük bir sayı tahmin edin!'
        else:
            message =f"Tebrikler! Doğru tahmin! {session['attempts']}"
            session.pop('number')
            session.pop('attempts')

        return render_template('index.html', message=message)
    return render_template('index.html', message=None)

if __name__=='__main__':
    app.run(debug=True)